package com.model;

public class Room {


}
