package com.service;
import com.model.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.List;

import com.management.NRIResidentManagement;
import com.management.RIResidentManagement;
import com.model.RIResident;
import com.util.ApplicationUtil;

public class NRIResidentService {
	NRIResident NRiR;
	NRIResidentManagement nrim= new NRIResidentManagement();
	public List<NRIResident> addNRIResidentDetails(String[]input) throws Exception {
		
		
	
		ApplicationUtil utilObj=new ApplicationUtil();
	    List<String> nriRecords=utilObj.NRIextractDetails(input);
	    List<NRIResident> nriList=new ArrayList<NRIResident>();
		nriList=buildNRIResidentList(nriRecords);
		 List<NRIResident> insertedRecord=nrim.insertNRIResidentIntoDB(nriList);
	
		
		return insertedRecord;
	}

	
	private List<NRIResident> buildNRIResidentList(List<String> nriRecords){
		List<NRIResident>nriList=new ArrayList<NRIResident>();
		int count =0;
		for(String nri:nriRecords) {
			count++;
			String[]field=nri.split(":");
			String residentId=getResidentId(count);
			String residentName=field[0];
			int age=Integer.parseInt(field[1]);
			String gender=field[2];
			long contactNumber=Long.parseLong(field[3]);
			 String email=field[4];
			 String address=field[5];
			 int numberOfAdults=Integer.parseInt(field[6]);
			 int numberOfChildrenAbove12=Integer.parseInt(field[7]);
			 int numberOfChildrenAbove5=Integer.parseInt(field[8]);
			 int durationOfStay=Integer.parseInt(field[9]);
			 String residentType=field[10];
			 String passportNo=field[11];
			 String passportType=field[12];
			 String nationality=field[13];
			 String purposeForVisit=field[14];

			 
			 NRiR=new NRIResident(residentId,residentName,age,gender,contactNumber,email,
			address,numberOfAdults,numberOfChildrenAbove12,numberOfChildrenAbove5,
			durationOfStay,residentType,passportNo,passportType,nationality,purposeForVisit);
			
			nriList.add(NRiR);
		}
		return nriList;
	}
	
     
	
	
	

	public String getResidentId(int count)
	{
		int total=nrim.getResidentId();
		total+=count;
		String s= "RIR"+total;
	
		return s;
	}
	
	
	
	
	public int updateNRIResidentPhoneNumberUsingPassportNumber(long pas,long contact_number) throws SQLException
	{
		
			int i=nrim.updateRIResidentPhoneNumberUsingPassportNumber(pas,contact_number);
			return i;
			
					
	}
		
	
	
	
	
	
	
	public int updateNRIResidentPhoneNumberUsingResidentId(String rid, long contact_number) throws SQLException
			
	{
		
		  int i=nrim.updateRIResidentPhoneNumberUsingResidentId(rid, contact_number);
		  return i;
		  
			
	}
	
	public boolean checkIdExists(String rid) {
		boolean i=nrim.checkIdExistsDB(rid);
		return i;
	}



	public int updateNRIResidentPhoneNumberUsingContactNumber(long old_con, long new_contact_number)throws SQLException 
	{
		int i=nrim.updateRIResidentPhoneNumberUsingContactNumber(old_con, new_contact_number);
		return i;
	}

	
	public int updateOccupancyUsingResidentId(int noOfAdults, int noOfChildrenAbove12, int noOfChildrenAbove5, String rid) throws SQLException 
		
		{
		
		int i=nrim.updateOccupancyUsingResidentIdDB(noOfAdults, noOfChildrenAbove12, noOfChildrenAbove5,rid);
		return i;
			
			
		}
	
	
	public int updateOccupancyUsingProof(int noOfAdults, int noOfChildrenAbove12, int noOfChildrenAbove5, long aad1) throws SQLException
		
		{
			int i=nrim.updateOccupancyUsingIdProofDB(noOfAdults, noOfChildrenAbove12, noOfChildrenAbove5,aad1);
			return i;
					
		}
	

	public int updateOccupancyUsingContactNumber(int noOfAdults, int noOfChildrenAbove12, int noOfChildrenAbove5, long contact_number1) throws SQLException
	
	{
		int i=nrim.updateOccupancyUsingContactNumberDB(noOfAdults, noOfChildrenAbove12, noOfChildrenAbove5,contact_number1);
		return i;
		
	}


	 public int deleteRIResidentTable(String del_res) {
	        return nrim.deleteNRIResidentDetailsFromDB(del_res);
	       
	    }
	 
	
	 
	
	 

public List<NRIResident> retrieveNRIResidentDetails(String residentId){
	List<NRIResident> list1=nrim.retrieveNRIResidentList(residentId);
	return list1;
}
}

//	
	
//		
	
	
	
	
