//package com.service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.model.RIResident;
//
//public class PaymentService {
//
//	public List<RIResident> addPaymentDetails(String[]input) throws Exception {
//	
//	}
//	
//	private List<RIResident> buildPaymentList(List<String> riRecords){
//		List<RIResident>riList1=new ArrayList<RIResident>();
//		return riList1;
//	}
//}
